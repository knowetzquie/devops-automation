// Generates a spine's look from its cover: average the cover's pixels into
// one dominant color, darken it slightly so it reads like cloth/board
// binding rather than a flat swatch, and size the spine from page count.

const FALLBACK_PALETTE = ['#6B4A3D', '#3E5C4A', '#4A5A70', '#7A4B5C', '#8A6D3F', '#4B4A6B', '#5C6B3E'];

function fallbackColor(seed) {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = seed.charCodeAt(i) + ((hash << 5) - hash);
  return FALLBACK_PALETTE[Math.abs(hash) % FALLBACK_PALETTE.length];
}

export function extractDominantColor(imgUrl) {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      try {
        const size = 24;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, size, size);
        const { data } = ctx.getImageData(0, 0, size, size);

        let r = 0, g = 0, b = 0, count = 0;
        for (let i = 0; i < data.length; i += 4) {
          if (data[i + 3] < 200) continue; // skip transparent pixels
          r += data[i];
          g += data[i + 1];
          b += data[i + 2];
          count++;
        }
        if (count === 0) return resolve(fallbackColor(imgUrl));

        const darken = (c) => Math.max(0, Math.round((c / count) * 0.85));
        resolve(`rgb(${darken(r)}, ${darken(g)}, ${darken(b)})`);
      } catch {
        // getImageData throws if the canvas got tainted (CORS) — fall back
        resolve(fallbackColor(imgUrl));
      }
    };

    img.onerror = () => resolve(fallbackColor(imgUrl));
    img.src = imgUrl;
  });
}

export function spineWidth(title, pages) {
  if (pages) return Math.min(56, Math.max(24, Math.round(pages / 12)));
  const base = 28 + (title.length % 20);
  return Math.min(52, base);
}
