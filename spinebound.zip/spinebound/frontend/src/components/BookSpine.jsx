import { useEffect, useState } from 'react';
import { extractDominantColor, spineWidth } from '../spineColor';
import { coverUrl } from '../api';

export default function BookSpine({ book, onRemove }) {
  const [color, setColor] = useState('#4A3A2C');
  const [open, setOpen] = useState(false);
  const cover = coverUrl(book.coverId, 'S');
  const width = spineWidth(book.title, book.pages);

  useEffect(() => {
    let active = true;
    if (cover) {
      extractDominantColor(cover).then((c) => active && setColor(c));
    }
    return () => {
      active = false;
    };
  }, [cover]);

  return (
    <div
      className="spine"
      style={{ backgroundColor: color, width: `${width}px` }}
      onClick={() => setOpen((v) => !v)}
      title={`${book.title} — ${book.author}`}
    >
      <span className="spine__title">{book.title}</span>
      {open && (
        <button
          className="spine__remove"
          onClick={(e) => {
            e.stopPropagation();
            onRemove(book.id);
          }}
          aria-label={`Remove ${book.title}`}
        >
          ×
        </button>
      )}
    </div>
  );
}
